/***** STRUCTS *****/
typedef struct node{
  struct node *next;
  char name[64];
  int priority;
}NODE;
